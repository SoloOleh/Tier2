# MCS-5-Advanced-JS

- Обробка помилок з try...catch
- Синтаксис async/await
- HTTP клієнт [Axios](https://axios-http.com/)